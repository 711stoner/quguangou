import { parseAccountList, parseAccountReference } from "./lib/accounts.js";
import { reserveAttempt } from "./lib/pacing.js";

const STORAGE_KEY = "quguangouJob";
const BLOCKLIST_CACHE_KEY = "quguangouBlocklistCache";
const REMOTE_BLOCKLIST_URL = "https://711stoner.github.io/quguangou/extension/data/blocklist.json";
const REMOTE_BLOCKLIST_TIMEOUT_MS = 6000;
const BATCH_SIZE = 20;
let activeRun = false;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function getJob() {
  const job = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] ?? null;
  // Repair the numeric handle in saved bundled jobs without rewriting historical results.
  if (job?.blocklistVersion === "2026.09.09.1") {
    job.targets = job.targets.map((target, index) => index >= job.currentIndex && target.key === "id:665162"
      ? parseAccountReference("@665162") : target);
  }
  if (job?.status === "paused" && !job.pauseKind && (job.resumeAt || /冷却|20 个账号/.test(job.pauseReason || ""))) {
    job.pauseKind = "batch";
  }
  return job;
}

async function setJob(job) {
  await chrome.storage.local.set({ [STORAGE_KEY]: job });
  chrome.runtime.sendMessage({ type: "JOB_UPDATED", job }).catch(() => {});
}

function normalizeBlocklist(payload, source, fetchedAt = null) {
  if (!payload || typeof payload !== "object") throw new Error("名单格式错误");
  if (!Array.isArray(payload.accounts)) throw new Error("名单格式错误：accounts 必须是数组");
  if (!payload.accounts.every((account) => typeof account === "string")) {
    throw new Error("名单格式错误：accounts 只能包含字符串");
  }
  const parsed = parseAccountList(payload.accounts.join("\n"), 1000);
  return {
    version: payload.version || "未标注",
    updatedAt: payload.updated_at || null,
    description: payload.description || "",
    reviewNote: payload.review_note || "",
    source,
    fetchedAt,
    ...parsed
  };
}

async function getRemoteBlocklist() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REMOTE_BLOCKLIST_TIMEOUT_MS);
  try {
    const response = await fetch(`${REMOTE_BLOCKLIST_URL}?t=${Date.now()}`, {
      cache: "no-store",
      credentials: "omit",
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`在线名单请求失败（HTTP ${response.status}）`);
    const payload = await response.json();
    const fetchedAt = new Date().toISOString();
    const blocklist = normalizeBlocklist(payload, "remote", fetchedAt);
    await chrome.storage.local.set({
      [BLOCKLIST_CACHE_KEY]: { payload, fetchedAt }
    });
    return blocklist;
  } finally {
    clearTimeout(timeout);
  }
}

async function getCachedBlocklist() {
  const cached = (await chrome.storage.local.get(BLOCKLIST_CACHE_KEY))[BLOCKLIST_CACHE_KEY];
  if (!cached?.payload) return null;
  try {
    return normalizeBlocklist(cached.payload, "cache", cached.fetchedAt || null);
  } catch {
    await chrome.storage.local.remove(BLOCKLIST_CACHE_KEY);
    return null;
  }
}

async function getBundledBlocklist() {
  const response = await fetch(chrome.runtime.getURL("data/blocklist.json"));
  if (!response.ok) throw new Error("无法读取扩展内置名单");
  return normalizeBlocklist(await response.json(), "bundled");
}

async function getBlocklist() {
  try {
    return await getRemoteBlocklist();
  } catch (error) {
    const cached = await getCachedBlocklist();
    if (cached) return { ...cached, remoteError: error.message || String(error) };
    const bundled = await getBundledBlocklist();
    return { ...bundled, remoteError: error.message || String(error) };
  }
}

async function getBlocklistForJob() {
  const cached = await getCachedBlocklist();
  const fetchedAt = cached?.fetchedAt ? Date.parse(cached.fetchedAt) : NaN;
  if (cached && Number.isFinite(fetchedAt) && Date.now() - fetchedAt < 5 * 60 * 1000) {
    return cached;
  }
  return getBlocklist();
}

async function waitForTabComplete(tabId, timeoutMs = 35_000) {
  const current = await chrome.tabs.get(tabId);
  if (current.status === "complete") return;

  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("页面加载超时"));
    }, timeoutMs);
    const listener = (updatedId, changeInfo) => {
      if (updatedId === tabId && changeInfo.status === "complete") {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function blockProfileInPage(target) {
  const sleepInPage = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const visible = (element) => Boolean(element && element.getClientRects().length);
  const waitFor = async (getter, timeoutMs = 15_000) => {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const value = getter();
      if (value) return value;
      await sleepInPage(250);
    }
    return null;
  };

  const pageText = () => document.body?.innerText || "";
  const unavailablePattern = /This account doesn.?t exist|Account suspended|账号不存在|帳戶不存在|账号已被冻结|アカウントは存在しません/i;
  const loginPattern = /Log in to X|Sign in to X|登录 X|登入 X/i;
  const blockPattern = /^(Block\b|拉黑|封鎖|ブロック|차단|Bloquear\b|Bloquer\b|Blockieren\b|Заблокировать)/i;
  const unblockPattern = /^(Unblock\b|取消拉黑|解除封鎖|ブロック解除|차단 해제|Desbloquear\b|Débloquer\b|Entsperren\b|Разблокировать)/i;
  const reportPattern = /report|举报|檢舉|報告|신고|denunciar|signaler|melden|пожаловаться/i;

  await waitFor(() => document.body, 10_000);
  if (/\/i\/flow\/login/.test(location.pathname) || loginPattern.test(pageText())) {
    return { status: "failed", reason: "当前浏览器中尚未登录 X" };
  }
  if (unavailablePattern.test(pageText())) return { status: "failed", reason: "账号不存在、已停用或无法访问" };

  const actions = await waitFor(() => {
    const profileActions = [...document.querySelectorAll('[data-testid="userActions"]')].filter(visible);
    for (const container of profileActions) {
      const controls = [
        ...container.querySelectorAll('button, [role="button"]'),
        ...(container.matches('button, [role="button"]') ? [container] : [])
      ].filter(visible);
      const moreControl = controls.find((item) => /more|更多/i.test(`${item.getAttribute("aria-label") || ""} ${item.innerText || ""}`));
      if (moreControl) return moreControl;
      const menuControl = controls.find((item) => (
        item.getAttribute("aria-haspopup") === "menu"
        && !/follow|关注|正在关注|unfollow|取关/i.test(`${item.getAttribute("aria-label") || ""} ${item.innerText || ""}`)
      ));
      if (menuControl) return menuControl;
    }
    return [...document.querySelectorAll('[data-testid="userActions"] button[aria-label], [data-testid="userActions"] [role="button"][aria-label]')]
      .filter(visible)
      .find((item) => /more|更多/i.test(item.getAttribute("aria-label") || "")) || null;
  });
  if (!actions) return { status: "failed", reason: "找不到用户操作菜单，X 页面结构可能已变化" };
  actions.click();
  await sleepInPage(350);

  const directAction = await waitFor(() => {
    const candidates = [...document.querySelectorAll('[data-testid="block"], [data-testid="unblock"]')].filter(visible);
    return candidates.find((item) => /unblock|取消拉黑|解除封鎖|ブロック解除|차단 해제/i.test(`${item.innerText} ${item.getAttribute("aria-label") || ""}`))
      || candidates.find((item) => /block|拉黑|封鎖|ブロック|차단/i.test(`${item.innerText} ${item.getAttribute("aria-label") || ""}`))
      || null;
  }, 2_000);
  if (directAction) {
    const text = `${directAction.innerText} ${directAction.getAttribute("aria-label") || ""}`;
    if (unblockPattern.test(text)) return { status: "already_blocked", reason: "该账号已经被拉黑" };
    directAction.click();
  }

  const menu = directAction ? null : await waitFor(() => {
    const menus = [...document.querySelectorAll('[role="menu"], [data-testid="Dropdown"]')].filter(visible);
    return menus.find((item) => item.querySelector('[role="menuitem"], [role="button"], button')) || menus[0] || null;
  }, 8_000);
  if (!directAction && !menu) return { status: "failed", reason: "资料页的“更多操作”菜单未打开；未点击左侧导航菜单" };
  const menuItems = menu ? [...menu.querySelectorAll('[role="menuitem"], [role="button"], button')].filter(visible) : [];
  const alreadyBlocked = menuItems.find((item) => unblockPattern.test(`${item.innerText.trim()} ${item.getAttribute("aria-label") || ""}`));
  if (alreadyBlocked) return { status: "already_blocked", reason: "该账号已经被拉黑" };

  const blockItem = directAction || menuItems.find((item) => {
    const text = `${item.innerText.trim()} ${item.getAttribute("aria-label") || ""}`;
    return blockPattern.test(text) && !reportPattern.test(text);
  });
  if (!blockItem) {
    const labels = menuItems.map((item) => item.innerText.trim()).filter(Boolean).slice(0, 8).join("、");
    return { status: "failed", reason: `菜单中找不到“拉黑”操作${labels ? `（当前菜单：${labels}）` : ""}` };
  }
  if (!directAction) blockItem.click();

  const confirm = await waitFor(() => {
    const byTestId = document.querySelector('[data-testid="confirmationSheetConfirm"]');
    if (visible(byTestId)) return byTestId;
    const dialog = [...document.querySelectorAll('[role="dialog"]')].find(visible);
    if (!dialog) return null;
    return [...dialog.querySelectorAll('button, [role="button"]')]
      .filter(visible)
      .find((button) => blockPattern.test(button.innerText.trim()) && !reportPattern.test(button.innerText));
  }, 8_000);
  if (!confirm) return { status: "failed", reason: "未出现拉黑确认窗口" };
  confirm.click();

  await sleepInPage(1200);
  const dialogStillOpen = [...document.querySelectorAll('[role="dialog"]')].some(visible);
  if (dialogStillOpen) return { status: "failed", reason: "确认后窗口未关闭，操作可能未成功" };
  return { status: "blocked", reason: "已拉黑" };
}

async function runJob() {
  if (activeRun) return;
  activeRun = true;
  try {
    let job = await getJob();
    if (!job || job.status !== "running") return;

    job.batchSize = job.batchSize || BATCH_SIZE;
    if (!Number.isInteger(job.batchStartIndex)) job.batchStartIndex = Math.floor(job.currentIndex / job.batchSize) * job.batchSize;
    if (!Number.isInteger(job.batchEndIndex)) job.batchEndIndex = Math.min(job.batchStartIndex + job.batchSize, job.targets.length);
    if (!Number.isInteger(job.batchNumber)) job.batchNumber = Math.floor(job.batchStartIndex / job.batchSize) + 1;
    const batchEndIndex = job.batchEndIndex;
    await setJob(job);

    if (!job.workerTabId) {
      const tab = await chrome.tabs.create({ url: "about:blank", active: false });
      job.workerTabId = tab.id;
      await setJob(job);
    }

    while (job.currentIndex < job.targets.length && job.currentIndex < batchEndIndex) {
      job = await getJob();
      if (!job || job.status !== "running") break;
      const quota = (await chrome.storage.local.get("quguangouQuota")).quguangouQuota || {};
      const reservation = reserveAttempt(quota);
      if (!reservation.allowed) {
        if (quota.cooldownUntil > Date.now()) {
          job.status = "paused";
          job.pauseKind = "batch";
          job.resumeAt = quota.cooldownUntil;
          job.pauseReason = "本批已处理 20 个账号，冷却 30 分钟后请手动继续下一批";
          await setJob(job);
          break;
        }
        await sleep(Math.min(1000, reservation.waitUntil - Date.now()));
        continue;
      }
      await chrome.storage.local.set({ quguangouQuota: reservation.state });
      const target = job.targets[job.currentIndex];
      job.currentTarget = target;
      await setJob(job);

      let outcome;
      try {
        await chrome.tabs.update(job.workerTabId, { url: target.url, active: false });
        await waitForTabComplete(job.workerTabId);
        await sleep(1200);
        const injection = await chrome.scripting.executeScript({
          target: { tabId: job.workerTabId },
          func: blockProfileInPage,
          args: [target]
        });
        outcome = injection[0]?.result ?? { status: "failed", reason: "页面脚本没有返回结果" };
      } catch (error) {
        outcome = { status: "failed", reason: error.message || String(error) };
      }

      job = await getJob();
      if (!job || job.status !== "running") break;
      job.results.push({ ...target, ...outcome, finishedAt: new Date().toISOString() });
      job.currentIndex += 1;
      job.currentTarget = null;
      if (reservation.state.cooldownUntil && job.currentIndex < job.targets.length) {
        job.status = "paused";
        job.pauseKind = "batch";
        job.resumeAt = reservation.state.cooldownUntil;
        job.pauseReason = "本批已处理 20 个账号，冷却 30 分钟后请手动继续下一批";
      }
      if (outcome.status === "failed") {
        job.status = "paused";
        job.pauseKind = "failure";
        job.resumeAt = null;
        job.pauseReason = "出现失败，已暂停；该账号页面已保留在浏览器标签页中。请先检查原因，再决定是否继续剩余账号";
        // Detach the diagnostic tab so cleanup and subsequent runs cannot close or reuse it.
        job.retainedTabId = job.workerTabId;
        job.workerTabId = null;
      }
      await setJob(job);
      await sleep(900);
    }

    job = await getJob();
    if (job?.workerTabId) {
      await chrome.tabs.remove(job.workerTabId).catch(() => {});
      job.workerTabId = null;
    }
    if (job?.status === "running") {
      if (job.currentIndex >= job.targets.length) {
        job.status = "completed";
        job.pauseKind = null;
        job.pauseReason = null;
        job.completedAt = new Date().toISOString();
      } else if (job.currentIndex >= batchEndIndex) {
        const quota = (await chrome.storage.local.get("quguangouQuota")).quguangouQuota || {};
        job.status = "paused";
        job.pauseKind = "batch";
        job.resumeAt = quota.cooldownUntil || Date.now() + 1_800_000;
        job.pauseReason = `第 ${job.batchNumber} 批已处理完成，冷却 30 分钟后请手动继续下一批`;
      }
    }
    if (job) await setJob(job);
  } finally {
    activeRun = false;
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_JOB") {
    getJob().then((job) => sendResponse({ ok: true, job }));
    return true;
  }
  if (message?.type === "GET_BLOCKLIST") {
    getBlocklist()
      .then((blocklist) => sendResponse({ ok: true, blocklist }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "START_BUNDLED_JOB") {
    (async () => {
      const existing = await getJob();
      if (activeRun || existing?.status === "running") {
        sendResponse({ ok: false, error: "已有任务正在执行" });
        return;
      }
      const quota = (await chrome.storage.local.get("quguangouQuota")).quguangouQuota || {};
      if (quota.cooldownUntil > Date.now()) {
        sendResponse({ ok: false, error: `本批已完成，请在 ${new Date(quota.cooldownUntil).toLocaleString()} 后手动继续下一批` });
        return;
      }
      if (existing && ["paused", "cancelled"].includes(existing.status) && existing.currentIndex < existing.targets.length) {
        const batchSize = existing.batchSize || BATCH_SIZE;
        const needsNewBatch = existing.pauseKind === "batch"
          || !Number.isInteger(existing.batchEndIndex)
          || existing.currentIndex >= existing.batchEndIndex;
        existing.batchSize = batchSize;
        if (needsNewBatch) {
          existing.batchStartIndex = existing.currentIndex;
          existing.batchEndIndex = Math.min(existing.currentIndex + batchSize, existing.targets.length);
          existing.batchNumber = Math.floor(existing.batchStartIndex / batchSize) + 1;
        }
        existing.status = "running";
        existing.pauseKind = null;
        existing.resumeAt = null;
        existing.pauseReason = null;
        await setJob(existing);
        sendResponse({ ok: true, job: existing });
        void runJob();
        return;
      }
      const blocklist = await getBlocklistForJob();
      if (!blocklist.targets.length) {
        sendResponse({ ok: false, error: "当前名单为空" });
        return;
      }
      const job = {
        id: crypto.randomUUID(),
        status: "running",
        blocklistVersion: blocklist.version,
        blocklistSource: blocklist.source,
        targets: blocklist.targets,
        results: [],
        currentIndex: 0,
        currentTarget: null,
        batchSize: BATCH_SIZE,
        batchNumber: 1,
        batchStartIndex: 0,
        batchEndIndex: Math.min(BATCH_SIZE, blocklist.targets.length),
        pauseKind: null,
        workerTabId: null,
        startedAt: new Date().toISOString()
      };
      await setJob(job);
      sendResponse({ ok: true, job });
      void runJob();
    })().catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "SKIP_COOLDOWN") {
    (async () => {
      const job = await getJob();
      if (activeRun || !job || job.status !== "paused" || job.pauseKind !== "batch" || job.currentIndex >= job.targets.length) {
        sendResponse({ ok: false, error: "当前没有可跳过的冷却任务" });
        return;
      }
      const quota = (await chrome.storage.local.get("quguangouQuota")).quguangouQuota || {};
      if (!(quota.cooldownUntil > Date.now())) {
        sendResponse({ ok: false, error: "冷却已经结束，请直接继续下一批" });
        return;
      }

      const previousResumeAt = quota.cooldownUntil;
      await chrome.storage.local.set({
        quguangouQuota: {
          ...quota,
          count: 0,
          cooldownUntil: 0
        }
      });

      const batchSize = job.batchSize || BATCH_SIZE;
      job.batchSize = batchSize;
      job.batchStartIndex = job.currentIndex;
      job.batchEndIndex = Math.min(job.currentIndex + batchSize, job.targets.length);
      job.batchNumber = Math.floor(job.batchStartIndex / batchSize) + 1;
      job.status = "running";
      job.pauseKind = null;
      job.resumeAt = null;
      job.pauseReason = null;
      job.skippedCooldowns = [
        ...(Array.isArray(job.skippedCooldowns) ? job.skippedCooldowns : []),
        { skippedAt: new Date().toISOString(), previousResumeAt }
      ];
      await setJob(job);
      sendResponse({ ok: true, job });
      void runJob();
    })().catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  if (message?.type === "CANCEL_JOB") {
    (async () => {
      const job = await getJob();
      if (job?.status === "running") {
        job.status = "cancelled";
        job.currentTarget = null;
        if (job.workerTabId) await chrome.tabs.remove(job.workerTabId).catch(() => {});
        job.workerTabId = null;
        await setJob(job);
      }
      sendResponse({ ok: true, job });
    })();
    return true;
  }
});

chrome.runtime.onStartup.addListener(() => void runJob());
void runJob();
